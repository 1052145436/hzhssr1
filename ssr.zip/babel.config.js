module.exports = {
    presets: [ [ '@vue/app', { useBuiltIns: 'entry' } ] ],
    plugins: [ 'syntax-dynamic-import' ],
    comments: false
}
