<template>
    <div class="notice-wapper">
        <div class="head-div">
            <HbHead></HbHead>
        </div>
        <div class="notice-s2">
            <div class="notice-s2-inner">
                <h1>联系我们</h1>
                <div class="txt-box">
                    <div class="txt-detail">
                        <h2>格洛博电子商务有限公司供应商合规专题须知</h2>
                        <p>依据中华人民共和国相关法律法规的规定和格洛博电子商务有限公司的规章制度，出于保障格洛博电子商务有限公司以及和格洛博
                            电子商务有限公司已有或将有持续良好合作关系的供应商合法权益的目的，现格洛博电子商务有限公司关于供应商的规定如下:</p>
                        <h3>一、企业供应商</h3>
                        <p>
                            1、持有中华人民共和国工商部门颁发的真实、合法、有效的营业执照及其相对应的合法公章，且保证其在格洛博电子商务有限公司

                            登记注册信息与营业执照完全一致;<br/>

                            2、提交以下相关证明文件并获得格洛博电子商务有限公司认可:<br>

                            （1）加盖企业公章的营业执照副本复印件；<br>

                            （2）加盖企业公章的税务登记证复印件（若是三证合一或五证合一则无需提供）；<br>

                            三证合一 ：是指企业依次申请的工商营业执照、组织机构代码证和税务登记证三证合为一证，提高市场准入效率。<br>

                            五证合一：营业执照、组织机构代码证、税务登记证、社会保险登记证和统计登记证为一证的“五证合一”登记制度。<br>

                            3、企业供应商合法公章的名称须与其提供的营业执照名称完全一致；<br>

                            4、企业供应商保证其后期在签署合同或单据填写时使用的是合法公章；<br>
                        </p>
                        <h3>二、个人供应商</h3>
                        <p>
                            1、持有中华人民共和国工商部门颁发的真实、合法、有效的营业执照及其相对应的合法公章，且保证其在格洛博电子商务有限公司

                            登记注册信息与营业执照相一致；<br>

                            2、提交以下相关证明文件并获得格洛博电子商务有限公司认可:<br>

                            （1）加盖企业公章的营业执照副本复印件；<br>

                            （2）个人身份证复印件；<br>

                            3、个人供应商合法公章的名称须与其提供的营业执照名称完全一致；<br>

                            4、个人供应商保证其后期在签署合同或单据填写时使用的是合法公章；<br>

                            5、若个人供应商可提供证明其合法经营，但无法提供公章的，需要提供一份证明并保证后期合作时在签署合同或巨额较大的交易单据上加盖自己本人手印；<br>

                            6、配合完成其它格洛博电子商务有限公司需要查验的信息。<br>
                        </p>
                        <h3>三、其他须知</h3>
                        <p>
                            1、供应商所填写的资料应当保障合法有效、不存在任何诈瞒、隐瞒、炸欺等行为，否则格洛博电子商务有限公司保留终止供应商使

                            用其提供各项服务的权利，且依法追究供应商由此造成的相应损失，损失包括但不限于支付的诉讼费、律师费、调查费及其他相关费

                            用。供应商信息如有变动，需要及时更新并向格洛博电子商务有限公司出具加盖公章的书面证明。<br/>

                            2、格洛博电子商务有限公司承诺：非经法定原因或供应商事先许可，格洛博电子商务有限公司不会向任何第三方透露供应商的姓名

                            、手机号码等非公开信息。在下述法定情况下，供应商的个人信息将会被部分或全部披露：<br/>

                            （1）经供应商同意向供应商一方或其他第三方披露；<br/>

                            （2）根据法律、法规等相关规定，或行政机构依其法定职权要求，向行政、司法机构或其他法律规定的第三方披露；<br/>

                            （3）其它格洛博电子商务有限公司根据法律、法规等相关规定进行的披露。<br/>

                            3、若在后续合作中供应商要求，格洛博电子商务有限公司可提供其营业执照复印件等文件供其查阅，但供应商必须保证格洛博电子<br/>

                            商务有限公司的文件等不得向第三人披露，否则由此给格洛博电子商务有限公司造成的一切损失由供应商承担。

                            4、格洛博电子商务有限公司在与供应商核价、订货等阶段时需多次核实供应商结算收款账户信息，供应商应保证其填写内容真实有

                            效无误，若因供应商提供的信息有误导致供应商无法结算收款，则格洛博电子商务有限公司不承担任何责任。<br/>

                            5、凡供应商依托本平台与格洛博电子商务有限公司达成交易的，均视为供应商知悉并同意由供应商或其委托的服务企业依法办理采

                            购标的之报关出境的相关手续并承担相应责任。此外，供应商亦同意委托格洛博电子商务有限公司指定的服务企业提供所采购标的在

                            中国大陆的物流配送服务（如运输、仓储、报关出境等），相应的服务费用可由格洛博电子商务有限公司直接向服务企业支付。<br/>

                            6、此须知最终解释权归格洛博电子商务有限公司所有。
                        </p>
                    </div>
                </div>
                <div class="supplier-promise">
                    <div class="btn-box">
                        <div class="sure-btn" id="agreen-btn">同意服务条款</div>
                        <div class="reset-btn" id="reset-btn">返回</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div style="width:100%;min-width:1200px;background:#000;">
            <introVersion></introVersion>
        </div>
    </div>
</template>
<script type="text/babel">
    import HbHead from '@/components/HbHead'
    import introVersion from '@/components/introVersion'

    export default {
        components: {
            HbHead,
            introVersion
        },
        data() {
            return {
                test: 'Hello World!'
            }
        },
        methods: {},
        mounted() {

        }
    }
</script>
<style lang="scss" type="text/scss" scoped>
    .clearfix:after {
        content: "020";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
    }

    .clearfix {
        /* 触发 hasLayout */
        zoom: 1;
    }

    .notice-wapper{
        width:100%;
        min-width:1200px;
        .head-div{
            width:100%;
            height:160px;
            overflow:hidden;
            background-color: #4c4c4c;
        }

        .notice-s2{
            background-color: #fff;

            .notice-s2-inner{
                box-shadow: 0 0 20px #888;
                width:1200px;
                margin:100px auto;
                position:relative;

                h1{
                    text-align:center;
                    font-size:36px;
                    line-height:36px;
                    color:#0074c2;
                    clear:both;
                    padding-top:70px;
                    padding-bottom:30px;
                    letter-spacing: 2px;
                    font-weight:400;
                    background-color: #eef8ff;
                    border-bottom:1px solid #e4e3e4;
                }
                .txt-box{
                    padding:40px 0px;
                    .txt-detail{
                        width:948px;
                        margin:0px auto;

                        h2,h3{
                            font-size:25px;
                            line-height:50px;
                            color:#434343;
                            text-align:center;
                            font-weight:400;
                            font-family: sans-serif;
                        }
                        h2{
                            text-align:center;
                        }
                        h3{
                            text-align:left;
                        }
                        p{
                            font-family: sans-serif;
                            font-size:16px;
                            line-height:35px;
                            color:#535353;
                        }
                    }
                }
                .supplier-promise{
                    width:1200px;
                    margin:0px auto;
                    background-color: #eef8ff;
                    padding:38px;

                    .btn-box{
                        width:670px;
                        height:90px;
                        margin:0px auto;
                        .sure-btn,.reset-btn{
                            width:324px;
                            height:84px;
                            line-height: 84px;
                            text-align: center;
                            font-size:36px;
                            -webkit-border-radius: 10px;
                            -moz-border-radius: 10px;
                            border-radius: 10px;
                            font-weight: 100;
                            letter-spacing: 2px;
                            cursor:pointer;
                        }
                        .sure-btn{
                            float:left;
                            background-color: #0074c2;
                            color:#fff;
                            border:1px solid #0074c2;

                            &:hover{
                                background-color: #0074a0;
                            }
                        }
                        .reset-btn{
                            float:right;
                            background-color: #fff;
                            color:#000;
                            border:1px solid #c9c9c9;

                            &:hover{
                                background-color: #aaa;
                                color:#fff;
                            }
                        }
                    }
                }
            }
        }
    }
</style>
