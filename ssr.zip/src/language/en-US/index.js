/**
 *
 * @author lucy <76573917@qq.com>
 * @created 2018/10/25 14:51
 */
import about from './modules/about'
import common from './modules/common'

export default {
    about,
    common
}
