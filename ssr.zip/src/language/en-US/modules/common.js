/**
 *
 * @author lucy <76573917@qq.com>
 * @created 2018/10/25 14:52
 */
export default {
    menu: {
        about: 'AboutUs',
        introduce: 'BusinessIntroduction',
        cultrue: 'GlobalCulture',
        recruit: 'JoinUs',
        supplier: 'ToBeASupplier',
        contact: 'ContactUs'
    },
    language: {
        'en-US': 'English',
        'zh-CN': 'Simplified Chinese'
    }
}
