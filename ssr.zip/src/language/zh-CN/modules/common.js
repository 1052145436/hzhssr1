/**
 *
 * @author lucy <76573917@qq.com>
 * @created 2018/10/25 14:52
 */
export default {
    menu: {
        about: '关于我们',
        introduce: '业务介绍',
        cultrue: '企业文化',
        recruit: '加入我们',
        supplier: '供应商入驻',
        contact: '联系我们'
    },
    language: {
        'en-US': '英文',
        'zh-CN': '简体中文'
    }
}
