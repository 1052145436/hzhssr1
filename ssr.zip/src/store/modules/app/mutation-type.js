/**
 * types
 * @author lucy <76573917@qq.com>
 * @created 2017-04-09 21:39
 */
export const TOKEN = 'TOKEN'
